#!/bin/bash
# ============================================================
# Бэкап СОСТОЯНИЯ системы: только данные (БД + загруженные файлы).
# Код проекта (PHP/JS/CSS) НЕ включается.
# ============================================================

set -e

PROJECT_DIR="/home/student/Документы/MillerPHP"
STATE_DIR="$PROJECT_DIR/backups/state"
DATE=$(date +%Y%m%d_%H%M%S)
KEEP_DAYS=30

DB_USER="admin"
DB_PASS="admin"
DB_NAME="library_db"

mkdir -p "$STATE_DIR"

# ============================================================
# 1. ДАМП БД — это и есть основное «состояние»
# ============================================================
echo "=== 1. Бэкап данных БД ==="
DB_FILE="$STATE_DIR/db_state_$DATE.sql"
mysqldump -u"$DB_USER" -p"$DB_PASS" --single-transaction --routines --triggers "$DB_NAME" > "$DB_FILE"

if [ ! -s "$DB_FILE" ]; then
    echo "ОШИБКА: дамп пуст"
    exit 1
fi
echo "OK: $DB_FILE ($(du -h "$DB_FILE" | cut -f1))"

# ============================================================
# 2. ЗАГРУЖЕННЫЕ ФАЙЛЫ (если есть)
# ============================================================
echo "=== 2. Бэкап загруженных файлов ==="

if [ -d "$PROJECT_DIR/assets/uploads" ] && [ "$(ls -A "$PROJECT_DIR/assets/uploads" 2>/dev/null)" ]; then
    UPLOADS_FILE="$STATE_DIR/uploads_state_$DATE.tar.gz"
    tar -czf "$UPLOADS_FILE" -C "$PROJECT_DIR" assets/uploads
    echo "OK: $UPLOADS_FILE ($(du -h "$UPLOADS_FILE" | cut -f1))"
else
    echo "SKIP: нет папки assets/uploads или она пуста"
fi

# ============================================================
# 3. ОЧИСТКА СТАРЫХ БЭКАПОВ
# ============================================================
echo "=== 3. Удаление бэкапов старше $KEEP_DAYS дней ==="
find "$STATE_DIR" -type f -mtime +$KEEP_DAYS -delete
echo "OK"

# ============================================================
echo ""
echo "✅ Бэкап состояния завершён:"
ls -lh "$STATE_DIR"