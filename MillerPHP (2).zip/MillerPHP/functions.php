<?php
/**
 * Триггеры и процедуры для системы "Центральная библиотека".
 * Подключается из config.php.
 */

// ============================================================
// ТРИГГЕР 1: Логирование изменений пользователей
// ============================================================
/**
 * Записывает в activity_log факт создания/обновления пользователя.
 * Вызывается из users.php после INSERT/UPDATE.
 */

/**
 * Проверка политики паролей (ТЗ 4.2.1):
 * минимум 6 символов, ≥1 цифра, ≥1 заглавная латинская, ≥1 строчная латинская.
 */
function password_policy_error(string $pass): ?string
{
    if (strlen($pass) < 6) {
        return 'Пароль минимум 6 символов.';
    }
    if (!preg_match('/\d/', $pass)) {
        return 'Пароль должен содержать хотя бы одну цифру.';
    }
    if (!preg_match('/[A-Z]/', $pass)) {
        return 'Пароль должен содержать хотя бы одну заглавную латинскую букву.';
    }
    if (!preg_match('/[a-z]/', $pass)) {
        return 'Пароль должен содержать хотя бы одну строчную латинскую букву.';
    }
    return null;
}
function trigger_user_changed(int $userId, string $action, array $old = [], array $new = []): void
{
    $currentUser = current_user();
    $changes = [];

    foreach ($new as $field => $value) {
        if (isset($old[$field]) && (string)$old[$field] !== (string)$value) {
            $changes[] = "$field: " . ($old[$field] ?? '—') . " → " . ($value ?? '—');
        }
    }

    $details = $changes ? implode('; ', $changes) : 'без изменений';
    $entity  = "user_id=$userId, $action: $details";

    try {
        $st = db()->prepare('INSERT INTO activity_log (user_id, action, entity) VALUES (?, ?, ?)');
        $st->execute([$currentUser['id'] ?? null, "Триггер: $action пользователя", $entity]);
    } catch (Throwable $e) {
        // логирование не должно ломать сценарий
    }
}

// ============================================================
// ТРИГГЕР 2: Автоблокировка после 3 ошибок
// ============================================================
/**
 * Проверяет failed_attempts; при >= 3 — блокирует.
 * Возвращает true, если пользователь заблокирован.
 */
function trigger_check_autoblock(array $user): bool
{
    if ((int)$user['is_blocked'] === 1) {
        return true;
    }

    $attempts = (int)$user['failed_attempts'];
    if ($attempts >= 3) {
        db()->prepare('UPDATE users SET is_blocked = 1, blocked_at = NOW(), blocked_until = DATE_ADD(NOW(), INTERVAL 1 HOUR) WHERE id = ?')
           ->execute([$user['id']]);
        log_action('Триггер: автоблокировка (3 ошибки, 1 час)', $user['login']);
        return true;
    }

    return false;
}

// ============================================================
// ТРИГГЕР 3: Защита от удаления единственного администратора
// ============================================================
/**
 * Возвращает [true, null] если удалять можно, [false, 'ошибка'] если нельзя.
 */
function trigger_protect_last_admin(int $userId): array
{
    $st = db()->prepare('SELECT login, role FROM users WHERE id = ?');
    $st->execute([$userId]);
    $user = $st->fetch();

    if (!$user) {
        return [false, 'Пользователь не найден.'];
    }

    if ($user['role'] !== 'admin') {
        return [true, null];
    }

    $st = db()->prepare("SELECT COUNT(*) FROM users WHERE role='admin' AND is_blocked=0 AND id <> ?");
    $st->execute([$userId]);
    $adminsLeft = (int)$st->fetchColumn();

    if ($adminsLeft === 0) {
        return [false, 'Нельзя удалить единственного администратора.'];
    }

    return [true, null];
}

// ============================================================
// ПРОЦЕДУРА 1: Создание пользователя с проверкой дубля
// ============================================================
/**
 * @return array{ok: bool, message: string, id?: int}
 */
function proc_create_user(string $login, string $name, string $email, string $pass, string $role): array
{
    if ($login === '')                              return ['ok' => false, 'message' => 'Укажите логин.'];
    if ($name === '')                               return ['ok' => false, 'message' => 'Укажите имя.'];
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) return ['ok' => false, 'message' => 'Некорректный email.'];
    $passErr = password_policy_error($pass);
if ($passErr !== null)                          return ['ok' => false, 'message' => $passErr];
    if (!in_array($role, ['admin','user'], true))   $role = 'user';

    // Проверка дубля логина
    $st = db()->prepare('SELECT 1 FROM users WHERE login = ?');
    $st->execute([$login]);
    if ($st->fetchColumn()) {
        return ['ok' => false, 'message' => "Пользователь с логином «{$login}» уже существует."];
    }

    // Проверка дубля email
    $st = db()->prepare('SELECT 1 FROM users WHERE email = ?');
    $st->execute([$email]);
    if ($st->fetchColumn()) {
        return ['ok' => false, 'message' => "Email «{$email}» уже используется."];
    }

    $initials = mb_strtoupper(
        mb_substr($name, 0, 1) . mb_substr(explode(' ', $name)[1] ?? '', 0, 1)
    );

    try {
        db()->prepare('INSERT INTO users (login, name, email, password_hash, role, avatar_initials)
                       VALUES (?,?,?,?,?,?)')
           ->execute([$login, $name, $email, password_hash($pass, PASSWORD_DEFAULT), $role, $initials]);

        $newId = (int)db()->lastInsertId();

        // Триггер 1
        trigger_user_changed($newId, 'Создание', [], [
            'login' => $login, 'name' => $name, 'email' => $email, 'role' => $role,
        ]);

        return ['ok' => true, 'message' => "Пользователь «{$login}» создан.", 'id' => $newId];
    } catch (PDOException $e) {
        if ($e->getCode() === '23000') {
            return ['ok' => false, 'message' => 'Пользователь с таким email или логином уже существует.'];
        }
        return ['ok' => false, 'message' => 'Ошибка БД: ' . $e->getMessage()];
    }
}

// ============================================================
// ПРОЦЕДУРА 2: Блокировка / разблокировка
// ============================================================
/**
 * @return array{ok: bool, message: string}
 */
function proc_toggle_block(int $userId, bool $block): array
{
    $st = db()->prepare('SELECT login, role FROM users WHERE id = ?');
    $st->execute([$userId]);
    $user = $st->fetch();

    if (!$user) {
        return ['ok' => false, 'message' => 'Пользователь не найден.'];
    }

    if ($block && $user['role'] === 'admin') {
        return ['ok' => false, 'message' => 'Нельзя блокировать администратора.'];
    }

        if ($block) {
        // Ручная блокировка — бессрочная (blocked_until = NULL)
        db()->prepare('UPDATE users SET is_blocked = 1, blocked_at = NOW(), blocked_until = NULL WHERE id = ?')
           ->execute([$userId]);
        log_action('Блокировка пользователя (вручную)', $user['login']);
        return ['ok' => true, 'message' => "Пользователь «{$user['login']}» заблокирован."];
    }

    db()->prepare('UPDATE users SET is_blocked = 0, failed_attempts = 0, blocked_at = NULL, blocked_until = NULL WHERE id = ?')
       ->execute([$userId]);
    log_action('Разблокировка пользователя', $user['login']);
    return ['ok' => true, 'message' => "Пользователь «{$user['login']}» разблокирован."];
}

// ============================================================
// ПРОЦЕДУРА 3: Статистика для дашборда
// ============================================================
/**
 * @return array{books:int, quantity:int, users:int, blocked:int, issued:int, overdue:int, notes:int, admins:int}
 */
function proc_get_stats(): array
{
    $pdo = db();

    return [
        'books'    => (int)$pdo->query('SELECT COUNT(*) FROM books')->fetchColumn(),
        'quantity' => (int)$pdo->query('SELECT COALESCE(SUM(quantity),0) FROM books')->fetchColumn(),
        'users'    => (int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn(),
        'blocked'  => (int)$pdo->query('SELECT COUNT(*) FROM users WHERE is_blocked=1')->fetchColumn(),
        'admins'   => (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='admin'")->fetchColumn(),
        'issued'   => (int)$pdo->query("SELECT COUNT(*) FROM books WHERE status='issued'")->fetchColumn(),
        'overdue'  => (int)$pdo->query("SELECT COUNT(*) FROM loans WHERE returned_at IS NULL AND due_at < CURDATE()")->fetchColumn(),
        'notes'    => (int)$pdo->query('SELECT COUNT(*) FROM notes')->fetchColumn(),
    ];
}