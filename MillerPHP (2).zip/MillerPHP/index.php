<?php
$title = 'Главная';
require __DIR__ . '/includes/header.php';

$isAdmin = $u['role'] === 'admin';

$stats = proc_get_stats();

// последние 7 дней — оставим (актуально для обоих: выдачи)
$rows = db()->query("
  SELECT DATE(created_at) d, COUNT(*) c FROM activity_log
  WHERE action='Выдача' AND created_at >= (CURDATE() - INTERVAL 6 DAY)
  GROUP BY DATE(created_at)")->fetchAll();
$byDay = array_column($rows,'c','d');
$days = []; $vals = [];
for ($i=6;$i>=0;$i--){
    $d = date('Y-m-d', strtotime("-$i day"));
    $days[] = date('d.m', strtotime($d));
    $vals[] = $byDay[$d] ?? 0;
}

// жанры — оставим (интересно читателю)
$genres = db()->query("SELECT COALESCE(genre,'Другое') g, COUNT(*) c FROM books GROUP BY g ORDER BY c DESC LIMIT 4")->fetchAll();

require __DIR__ . '/includes/sidebar.php';
?>
<h1><?= $isAdmin ? 'Библиотека в цифрах' : 'Добро пожаловать в библиотеку' ?></h1>
<p class="muted">
  <?= $isAdmin
      ? 'Всё самое важное о фонде, читателях и выдачах — в одном месте.'
      : 'Ищите книги в каталоге, следите за новинками и оставайтесь на связи.' ?>
</p>

<section class="cards">
  <div class="card">
    <div class="k">Книг</div>
    <div class="v"><?= number_format($stats['quantity'],0,'',' ') ?></div>
    <div class="s"><?= $stats['books'] ?> позиций</div>
  </div>
  <?php if ($isAdmin): ?>
    <div class="card">
      <div class="k">Пользователей</div>
      <div class="v"><?= $stats['users'] ?></div>
      <div class="s"><?= $stats['blocked'] ?> заблокировано</div>
    </div>
  <?php endif; ?>
  <div class="card">
    <div class="k">Выдано</div>
    <div class="v"><?= $stats['issued'] ?></div>
    <div class="s">на руках у читателей</div>
  </div>
  <div class="card">
    <div class="k">Просрочено</div>
    <div class="v"><?= $stats['overdue'] ?></div>
    <div class="s">требуют напоминания</div>
  </div>
</section>

<section class="panel">
  <h2>Выдачи за 7 дней</h2>
  <canvas id="weekChart" height="140"></canvas>
</section>

<section class="grid2">
  <div class="panel">
    <h2>Жанры</h2>
    <ul class="genres">
      <?php foreach ($genres as $g): ?>
        <li><span><?= e($g['g']) ?></span><b><?= $g['c'] ?></b></li>
      <?php endforeach; ?>
    </ul>
  </div>
  <div class="panel">
    <h2>Быстрые действия</h2>
    <div class="quick">
      <a class="btn" href="catalog.php">📚 Каталог книг</a>
      <?php if ($isAdmin): ?>
        <a class="btn" href="catalog.php?add=1">+ Добавить книгу</a>
        <a class="btn" href="users.php?add=1">Создать юзера</a>
        <a class="btn" href="catalog.php?export=1">Экспорт</a>
      <?php else: ?>
        <a class="btn" href="contacts.php">✉ Связаться с библиотекой</a>
        <a class="btn" href="about.php">ℹ О библиотеке</a>
      <?php endif; ?>
    </div>
  </div>
</section>

<?php if ($isAdmin): ?>
<section class="panel">
  <h2>Последние действия</h2>
  <?php
    $actions = db()->query("
      SELECT a.created_at, a.action, a.entity, u.name AS user_name
      FROM activity_log a LEFT JOIN users u ON u.id=a.user_id
      ORDER BY a.id DESC LIMIT 8")->fetchAll();
  ?>
  <table class="table">
    <thead><tr><th>Время</th><th>Книга / событие</th><th>Сотрудник</th></tr></thead>
    <tbody>
    <?php foreach ($actions as $a): ?>
      <tr>
        <td><?= date('H:i', strtotime($a['created_at'])) ?></td>
        <td><?= e($a['entity'] ?: $a['action']) ?></td>
        <td><?= e($a['user_name'] ?: '—') ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</section>
<?php endif; ?>

<script>
window.weekChartData = { labels: <?= json_encode($days) ?>, values: <?= json_encode($vals) ?> };
</script>
<?php require __DIR__ . '/includes/footer.php'; ?>