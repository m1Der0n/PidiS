document.addEventListener('DOMContentLoaded', () => {
  const c = document.getElementById('weekChart');
  if (!c || !window.weekChartData) return;
  const { labels, values } = window.weekChartData;
  const ctx = c.getContext('2d');
  const W = c.width = c.parentElement.clientWidth - 32;
  const H = c.height;
  const pad = { l: 36, r: 12, t: 12, b: 28 };
  const max = Math.max(10, ...values) * 1.15;

  ctx.clearRect(0, 0, W, H);
  ctx.strokeStyle = '#e7e9f0'; ctx.fillStyle = '#7b8194'; ctx.font = '12px system-ui';

  for (let i = 0; i <= 4; i++) {
    const y = pad.t + (H - pad.t - pad.b) * i / 4;
    ctx.beginPath(); ctx.moveTo(pad.l, y); ctx.lineTo(W - pad.r, y); ctx.stroke();
    ctx.fillText(Math.round(max - (max * i / 4)), 4, y + 4);
  }

  const stepX = (W - pad.l - pad.r) / (values.length - 1);
  const pt = (i) => [pad.l + i * stepX, H - pad.b - (values[i] / max) * (H - pad.t - pad.b)];

  ctx.beginPath();
  values.forEach((_, i) => { const [x, y] = pt(i); i ? ctx.lineTo(x, y) : ctx.moveTo(x, y); });
  ctx.strokeStyle = '#1e2a78'; ctx.lineWidth = 2; ctx.stroke();

  values.forEach((_, i) => {
    const [x, y] = pt(i);
    ctx.beginPath(); ctx.arc(x, y, 4, 0, Math.PI * 2);
    ctx.fillStyle = '#fff'; ctx.fill();
    ctx.strokeStyle = '#1e2a78'; ctx.lineWidth = 2; ctx.stroke();
    ctx.fillStyle = '#7b8194'; ctx.fillText(labels[i], x - 14, H - 8);
  });
});