(function () {
  const puzzle     = document.getElementById('puzzle');
  if (!puzzle) return;

  const msg        = document.getElementById('captchaMsg');
  const doneBtn    = document.getElementById('doneBtn');
  const shuffleBtn = document.getElementById('shuffleBtn');
  const box        = document.getElementById('captchaBox');
  const loginInput = document.querySelector('input[name=login]');
  const passInput  = document.querySelector('input[name=password]');
  const submitBtn  = document.querySelector('form.auth-card button[type=submit]');

  const state = { imageByPart: [], current: [0, 1, 2, 3] };
  let dragFrom = null;
  let selected = null;
  let passed = false;
  let captchaLoaded = false;
  let loadTimer = null;

  function setMsg(text, ok = false) {
    if (!msg) return;
    msg.textContent = text;
    msg.className = ok ? 'ok' : 'error';
  }

  function lockSubmit(lock) {
    if (!submitBtn) return;
    submitBtn.disabled = lock;
    submitBtn.style.opacity = lock ? '.5' : '1';
    submitBtn.style.cursor  = lock ? 'not-allowed' : 'pointer';
  }

  function loginAndPasswordFilled() {
    const l = loginInput ? loginInput.value.trim() : '';
    const p = passInput  ? passInput.value.trim()  : '';
    return l !== '' && p !== '';
  }

  function markPassed() {
    passed = true;
    if (box) box.classList.add('done');
    setMsg('Капча пройдена ✓', true);
    if (doneBtn) doneBtn.disabled = true;
    if (shuffleBtn) shuffleBtn.disabled = true;
    lockSubmit(false);
  }

  function render() {
    [...puzzle.children].forEach((tile, slot) => {
      const partIdx = state.current[slot];
      tile.firstChild.src = state.imageByPart[partIdx];
    });
  }

  function swap(a, b) {
    if (a === b || a === null || b === null || passed) return;
    [state.current[a], state.current[b]] = [state.current[b], state.current[a]];
    render();
    setMsg('');
  }

  function makeTiles() {
    puzzle.innerHTML = '';
    for (let slot = 0; slot < 4; slot++) {
      const wrap = document.createElement('div');
      wrap.className = 'tile';
      wrap.draggable = true;

      const img = document.createElement('img');
      img.alt = '';
      wrap.appendChild(img);

      wrap.addEventListener('dragstart', () => { dragFrom = slot; });
      wrap.addEventListener('dragover', e => e.preventDefault());
      wrap.addEventListener('drop', e => { e.preventDefault(); swap(dragFrom, slot); });
      wrap.addEventListener('click', () => {
        if (passed) return;
        if (selected === null) { selected = slot; wrap.classList.add('selected'); return; }
        if (selected === slot) { wrap.classList.remove('selected'); selected = null; return; }
        puzzle.children[selected]?.classList.remove('selected');
        swap(selected, slot);
        selected = null;
      });
      puzzle.appendChild(wrap);
    }
    render();
  }

  async function load() {
    if (passed) return;

    if (!loginAndPasswordFilled()) {
      puzzle.innerHTML = '';
      setMsg('Введите логин и пароль, чтобы получить капчу.', false);
      captchaLoaded = false;
      return;
    }

    setMsg('Загрузка капчи...');
    if (box) box.classList.remove('done');
    captchaLoaded = false;

    try {
      const r = await fetch('api.php?action=captcha.new', { method: 'POST' });
      const d = await r.json();
      if (!d.ok) { setMsg(d.error || 'Не удалось получить задание'); return; }

      const byPart = [];
      for (let slot = 0; slot < 4; slot++) {
        byPart[d.order[slot]] = d.images[slot];
      }

      state.imageByPart = byPart;
      state.current     = [...d.order];
      makeTiles();
      captchaLoaded = true;
      setMsg('');
    } catch (e) {
      setMsg('Сеть недоступна');
    }
  }

  async function check() {
    if (passed) return;

    if (!loginAndPasswordFilled()) {
      setMsg('Сначала введите логин и пароль.', false);
      return;
    }
    if (!captchaLoaded) {
      setMsg('Дождитесь загрузки капчи.', false);
      return;
    }

    const fd = new FormData();
    fd.append('answer', state.current.join(','));
    fd.append('login', loginInput ? loginInput.value.trim() : '');
    fd.append('password', passInput ? passInput.value : '');

    try {
      const r = await fetch('api.php?action=captcha.check', { method: 'POST', body: fd });
      const d = await r.json();

      if (d.ok) { markPassed(); return; }

      setMsg(d.error || 'Неверно');
      captchaLoaded = false;
      await load();
    } catch (e) {
      setMsg('Сеть недоступна');
    }
  }

  function maybeLoadCaptcha() {
    if (passed) return;
    clearTimeout(loadTimer);

    if (loginAndPasswordFilled()) {
      if (!captchaLoaded) loadTimer = setTimeout(load, 300);
    } else {
      captchaLoaded = false;
      puzzle.innerHTML = '';
      setMsg('Введите логин и пароль, чтобы получить капчу.', false);
    }
  }

  doneBtn?.addEventListener('click', check);
  shuffleBtn?.addEventListener('click', () => {
    if (!loginAndPasswordFilled()) {
      setMsg('Введите логин и пароль.', false);
      return;
    }
    captchaLoaded = false;
    load();
  });

  loginInput?.addEventListener('input', maybeLoadCaptcha);
  passInput?.addEventListener('input', maybeLoadCaptcha);

  lockSubmit(true);
  setMsg('Введите логин и пароль, чтобы получить капчу.', false);

  // Если браузер автозаполнил поля — пробуем загрузить капчу сразу
  if (loginAndPasswordFilled()) maybeLoadCaptcha();
})();