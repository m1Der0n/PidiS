<?php
require __DIR__ . '/auth.php';   // ← ЗАМЕНА: было config.php

$u = auth_require();

// Фильтры
$q        = trim($_GET['q'] ?? '');
$author   = trim($_GET['author'] ?? '');
$genre    = $_GET['genre'] ?? '';
$status   = $_GET['status'] ?? '';
$dateFrom = $_GET['date_from'] ?? '';
$dateTo   = $_GET['date_to'] ?? '';

$where  = [];
$params = [];
$needJoin = false;

if ($q !== '')      { $where[] = 'b.title LIKE ?';  $params[] = "%$q%"; }
if ($author !== '') { $where[] = 'b.author LIKE ?'; $params[] = "%$author%"; }
if ($genre !== '')  { $where[] = 'b.genre = ?';     $params[] = $genre; }
if ($status !== '') { $where[] = 'b.status = ?';    $params[] = $status; }
if ($dateFrom !== '') { $where[] = 'DATE(l.taken_at) >= ?'; $params[] = $dateFrom; $needJoin = true; }
if ($dateTo !== '')   { $where[] = 'DATE(l.taken_at) <= ?'; $params[] = $dateTo;   $needJoin = true; }

$w = $where ? 'WHERE ' . implode(' AND ', $where) : '';
$join = $needJoin ? 'INNER JOIN loans l ON l.book_id = b.id' : '';

$st = db()->prepare("
    SELECT DISTINCT b.*
    FROM books b
    $join
    $w
    ORDER BY b.title
");
$st->execute($params);
$books = $st->fetchAll();

$statuses = ['available'=>'В наличии', 'issued'=>'Выдана', 'repair'=>'На ремонте'];
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<title>Каталог книг — PDF</title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body class="pdf-body">

<button class="pdf-print-btn" onclick="window.print()">🖨 Печать / Сохранить PDF</button>

<div class="pdf-header">
  <h1>Каталог книг — Центральная библиотека</h1>
  <div class="pdf-meta">
    Отчёт сформирован: <b><?= date('d.m.Y H:i') ?></b> · 
    Пользователь: <b><?= e($u['name']) ?></b> · 
    Всего книг: <b><?= count($books) ?></b>
  </div>
</div>

<?php if ($q || $author || $genre || $status || $dateFrom || $dateTo): ?>
  <div class="pdf-filters-info">
    <b>Применённые фильтры:</b>
    <?php if ($q): ?> · Название: «<?= e($q) ?>»<?php endif; ?>
    <?php if ($author): ?> · Автор: «<?= e($author) ?>»<?php endif; ?>
    <?php if ($genre): ?> · Жанр: <?= e($genre) ?><?php endif; ?>
    <?php if ($status): ?> · Статус: <?= e($statuses[$status] ?? $status) ?><?php endif; ?>
    <?php if ($dateFrom || $dateTo): ?> · Выдана: <?= e($dateFrom ?: '...') ?> — <?= e($dateTo ?: '...') ?><?php endif; ?>
  </div>
<?php endif; ?>

<?php if (!$books): ?>
  <div class="pdf-no-data">По вашему запросу ничего не найдено.</div>
<?php else: ?>
  <table class="pdf-table">
    <thead>
      <tr>
        <th class="pdf-col-num">№</th>
        <th>Название</th>
        <th>Автор</th>
        <th>ISBN</th>
        <th class="pdf-col-year">Год</th>
        <th class="pdf-col-qty">Кол-во</th>
        <th class="pdf-col-status">Статус</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($books as $i => $b): ?>
        <tr>
          <td><?= $i + 1 ?></td>
          <td><b><?= e($b['title']) ?></b></td>
          <td><?= e($b['author']) ?></td>
          <td><?= e($b['isbn']) ?></td>
          <td><?= (int)$b['year'] ?></td>
          <td><?= (int)$b['quantity'] ?></td>
          <td class="pdf-status-<?= e($b['status']) ?>">
            <?= e($statuses[$b['status']] ?? $b['status']) ?>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
<?php endif; ?>

<div class="pdf-footer">
  Центральная библиотека · Каталог сформирован автоматически · <?= date('d.m.Y H:i') ?>
</div>

</body>
</html>