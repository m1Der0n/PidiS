<?php
$u = $u ?? (function_exists('auth_user') ? auth_user() : null);
$isAdmin = $u && $u['role'] === 'admin';
$isGuest = !$u;
?>
<aside class="sidebar">
  <div class="brand">РАБОЧЕЕ ПРОСТРАНСТВО<br><b>Центральная библиотека</b></div>
  <nav>
    <?php if (!$isGuest): ?>
      <a href="index.php"    class="<?= basename($_SERVER['PHP_SELF'])==='index.php'?'active':'' ?>">Главная</a>
    <?php endif; ?>
    <a href="catalog.php"  class="<?= basename($_SERVER['PHP_SELF'])==='catalog.php'?'active':'' ?>">Каталог</a>
    <a href="about.php"    class="<?= basename($_SERVER['PHP_SELF'])==='about.php'?'active':'' ?>">О нас</a>
    <?php if (!$isGuest): ?>
      <a href="contacts.php" class="<?= basename($_SERVER['PHP_SELF'])==='contacts.php'?'active':'' ?>">Контакты</a>
    <?php endif; ?>
    <?php if ($isAdmin): ?>
      <a href="users.php"   class="<?= basename($_SERVER['PHP_SELF'])==='users.php'?'active':'' ?>">Управление</a>
      <a href="backups.php" class="<?= basename($_SERVER['PHP_SELF'])==='backups.php'?'active':'' ?>">Бэкапы</a>
    <?php endif; ?>
  </nav>
  <div class="side-bottom">
    <div class="help">Нужна помощь?<br><small>Инструкции и поддержка</small></div>
    <?php if ($isGuest): ?>
      <a href="login.php">→ Войти в систему</a>
    <?php else: ?>
      <a href="logout.php">→ Выйти из системы</a>
    <?php endif; ?>
    <small class="muted">Библиотека • v 2.4</small>
  </div>
</aside>
<main class="content">
  <header class="topbar">
    <div><?= date('l, j F Y') ?></div>
    <div class="user">
      <?php if ($isGuest): ?>
        <span class="avatar">Г</span> Гость
      <?php else: ?>
        <span class="avatar"><?= e($u['initials'] ?: mb_substr($u['name'],0,2)) ?></span>
        <?= e($u['name']) ?>
        <small><?= $isAdmin ? 'Сотрудник' : 'Читатель' ?></small>
      <?php endif; ?>
    </div>
  </header>