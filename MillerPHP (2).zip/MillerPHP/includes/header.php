<?php
require_once __DIR__ . '/../auth.php';

$title      = $title ?? 'Библиотека';
$publicPage = $publicPage ?? false;   // ← флаг: страница доступна гостю

if ($publicPage) {
    $u = auth_user();                 // может быть null — это нормально
} else {
    $u = auth_require();              // приватная страница: только авторизованные
}
?>
<!doctype html>
<html lang="ru"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= e($title) ?> — Центральная библиотека</title>
<link rel="stylesheet" href="assets/style.css">
</head><body class="app">
<div class="layout">