<?php
session_start();

const DB_HOST = 'localhost';
const DB_NAME = 'library_db';
const DB_USER = 'admin';
const DB_PASS = 'admin';

function db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
    }
    return $pdo;
}

function e($s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

function current_user(): ?array { return $_SESSION['user'] ?? null; }

function require_auth(): void {
    if (!current_user()) { header('Location: login.php'); exit; }
}

function log_action(string $action, ?string $entity = null): void {
    $u = current_user();
    try {
        $st = db()->prepare('INSERT INTO activity_log (user_id, action, entity) VALUES (?,?,?)');
        $st->execute([$u['id'] ?? null, $action, $entity]);
    } catch (Throwable $e) {
        // логирование не должно ломать основной сценарий
    }
}

function setting_get(string $k, $default = null) {
    $st = db()->prepare('SELECT v FROM settings WHERE k = ?');
    $st->execute([$k]);
    $v = $st->fetchColumn();
    return $v === false ? $default : $v;
}

function setting_set(string $k, string $v): void {
    $st = db()->prepare('INSERT INTO settings (k,v) VALUES (?,?) ON DUPLICATE KEY UPDATE v = VALUES(v)');
    $st->execute([$k, $v]);
}

/* ---------- Flash-сообщения (одноразовые) ---------- */
function flash_set(string $type, string $text): void {
    $_SESSION['flash'] = ['type' => $type, 'text' => $text];
}
function flash_get(): ?array {
    $f = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $f;
}

/* ---------- Тексты сообщений из ТЗ №1 ---------- */
const MSG_BAD_LOGIN = 'Вы ввели неверный логин или пароль. Пожалуйста проверьте ещё раз введенные данные';
const MSG_BLOCKED   = 'Вы заблокированы. Обратитесь к администратору';
const MSG_SUCCESS   = 'Вы успешно авторизовались';
const MSG_CAPTCHA   = 'Соберите пазл правильно, чтобы продолжить';

/* ---------- Триггеры и процедуры ---------- */
require_once __DIR__ . '/functions.php';