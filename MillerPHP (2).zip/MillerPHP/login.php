<?php
require __DIR__ . '/auth.php';

// Уже авторизован — на главную
if (auth_user()) {
    header('Location: index.php');
    exit;
}

$error = null;

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login    = trim($_POST['login'] ?? '');
    $password = $_POST['password'] ?? '';
    $captcha  = !empty($_SESSION['captcha_passed']);

    [$ok, $message] = auth_attempt($login, $password, $captcha);

    if ($ok) {
        flash_set('info', $message);
        header('Location: index.php');
        exit;
    }
    $error = $message;
}

$flash = flash_get();
?>
<!doctype html>
<html lang="ru"><head><meta charset="utf-8">
<title>Вход — Управление библиотекой</title>
<link rel="stylesheet" href="assets/style.css"></head>
<body class="auth-page">
  <form class="auth-card" method="post" novalidate>
    <h1>Управление библиотекой</h1>

    <?php if ($flash): ?>
      <p class="<?= $flash['type'] === 'info' ? 'ok' : 'error' ?>"><?= e($flash['text']) ?></p>
    <?php endif; ?>

    <label>Логин<input name="login" value="<?= e($_POST['login'] ?? '') ?>" required autocomplete="username"></label>
    <label>Пароль<input type="password" name="password" required autocomplete="current-password"></label>

    <div id="captchaBox" class="captcha">
      <p>Соберите картинку из фрагментов и нажмите «Готово».</p>
      <div class="puzzle" id="puzzle"></div>
      <div class="captcha-actions">
        <button type="button" class="btn" id="shuffleBtn">Перемешать</button>
        <button type="button" class="btn primary" id="doneBtn">Готово</button>
      </div>
      <small id="captchaMsg"></small>
    </div>

    <?php if ($error): ?><p class="error"><?= e($error) ?></p><?php endif; ?>

        <button class="btn primary big" type="submit" disabled>Войти</button>
    <p class="muted">Забыли пароль? Свяжитесь с администратором</p>
  </form>
  <script src="assets/login.js"></script>
</body></html>