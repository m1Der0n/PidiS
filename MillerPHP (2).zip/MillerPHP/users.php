<?php
$title = 'Управление';
require __DIR__ . '/includes/header.php';

$u = auth_require();

// Только сотрудник (админ) может управлять пользователями
if ($u['role'] !== 'admin') {
    http_response_code(403);
    header('Location: index.php');
    exit;
}

$errors = [];   // ← объявляем заранее, чтобы была определена всегда

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // ============================================================
    // ПРОЦЕДУРА 1: создание пользователя
    // ============================================================
    if ($action === 'create') {
        $result = proc_create_user(
            trim($_POST['login'] ?? ''),
            trim($_POST['name'] ?? ''),
            trim($_POST['email'] ?? ''),
            $_POST['password'] ?? '',
            $_POST['role'] ?? 'user'
        );

        if ($result['ok']) {
            flash_set('info', $result['message']);
            header('Location: users.php'); exit;
        }
        $errors[] = $result['message'];
    }

    // ============================================================
    // Обновление (с триггером 1)
    // ============================================================
    if ($action === 'update') {
        $id    = (int)($_POST['id'] ?? 0);
        $name  = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $role  = in_array($_POST['role'] ?? '', ['admin', 'user'], true) ? $_POST['role'] : 'user';
        $pass  = $_POST['password'] ?? '';

        if ($id <= 0) $errors[] = 'Некорректный id.';
        if ($name === '') $errors[] = 'Укажите имя.';
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Некорректный email.';

        if (!$errors) {
            // Сохраняем старые данные для триггера
            $oldSt = db()->prepare('SELECT name, email, role FROM users WHERE id = ?');
            $oldSt->execute([$id]);
            $oldRow = $oldSt->fetch() ?: [];

            $sql = 'UPDATE users SET name=?, email=?, role=?';
            $params = [$name, $email, $role];
            if ($pass !== '') {
    $passErr = password_policy_error($pass);
    if ($passErr !== null) $errors[] = $passErr;
    else { $sql .= ', password_hash=?'; $params[] = password_hash($pass, PASSWORD_DEFAULT); }
}
            if (!$errors) {
                $sql .= ' WHERE id=?'; $params[] = $id;
                db()->prepare($sql)->execute($params);

                // Триггер 1
                trigger_user_changed($id, 'Обновление', $oldRow, [
                    'name' => $name, 'email' => $email, 'role' => $role,
                ]);

                flash_set('info', 'Данные пользователя обновлены.');
                header('Location: users.php'); exit;
            }
        }
    }

    // ============================================================
    // ПРОЦЕДУРА 2: разблокировка
    // ============================================================
    if ($action === 'unblock') {
        $result = proc_toggle_block((int)($_POST['id'] ?? 0), false);
        flash_set($result['ok'] ? 'info' : 'error', $result['message']);
        header('Location: users.php'); exit;
    }

        // ============================================================
    // ПРОЦЕДУРА 2: блокировка (ручная)
    // ============================================================
    if ($action === 'block') {
        $result = proc_toggle_block((int)($_POST['id'] ?? 0), true);
        flash_set($result['ok'] ? 'info' : 'error', $result['message']);
        header('Location: users.php'); exit;
    }

    // ============================================================
    // Удаление (с триггером 3)
    // ============================================================
    if ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);

        if ($id === (int)$u['id']) {
            flash_set('error', 'Нельзя удалить самого себя.');
            header('Location: users.php'); exit;
        }

        [$canDelete, $deleteError] = trigger_protect_last_admin($id);
        if (!$canDelete) {
            flash_set('error', $deleteError);
            header('Location: users.php'); exit;
        }

        db()->prepare('DELETE FROM users WHERE id=?')->execute([$id]);
        flash_set('info', 'Пользователь удалён.');
        header('Location: users.php'); exit;
    }
}

$q = trim($_GET['q'] ?? '');
$st = db()->prepare('SELECT id,login,name,email,role,avatar_initials,is_blocked,failed_attempts,created_at
                     FROM users WHERE login LIKE ? OR name LIKE ? OR email LIKE ? ORDER BY id DESC LIMIT 100');
$st->execute(["%$q%","%$q%","%$q%"]);
$users = $st->fetchAll();
$count = (int) db()->query('SELECT COUNT(*) FROM users')->fetchColumn();

require __DIR__ . '/includes/sidebar.php';
$flash = flash_get();
?>
<h1>Команда и читатели</h1>
<?php if ($flash): ?>
  <p class="<?= $flash['type']==='info'?'ok':'error' ?>">
    <?= $flash['type']==='info' ? '✅' : '⚠️' ?> <?= e($flash['text']) ?>
  </p>
<?php endif; ?>

<?php if ($errors): ?>
  <div class="error">
    <?php foreach ($errors as $err): ?>
      <p>⚠️ <?= e($err) ?></p>
    <?php endforeach; ?>
  </div>
<?php endif; ?>

<form class="filters" method="get">
  <input name="q" placeholder="Поиск по логину, имени, email" value="<?= e($q) ?>">
  <a class="btn primary" href="users.php?add=1">Создать пользователя</a>
  <a class="btn" href="backups.php" style="background:#eef0fb">💾 Бэкапы</a>
</form>

<table class="table">
  <thead><tr><th>Логин</th><th>Имя</th><th>Email</th><th>Роль</th><th>Статус</th><th></th></tr></thead>
  <tbody>
  <?php foreach ($users as $x): ?>
    <tr>
      <td><b><?= e($x['login']) ?></b></td>
      <td><?= e($x['name']) ?></td>
      <td><?= e($x['email']) ?></td>
      <td><?= $x['role']==='admin' ? 'Администратор' : 'Пользователь' ?></td>
            <td>
        <?php if ((int)$x['is_blocked']===1): ?>
                    <span class="badge repair">
            Заблокирован (<?= (int)$x['failed_attempts'] ?>)
            <?php if (!empty($x['blocked_until'])): ?>
              <br><small>до <?= date('d.m.Y H:i', strtotime($x['blocked_until'])) ?></small>
            <?php endif; ?>
          </span>
          <form method="post" style="display:inline">
            <input type="hidden" name="action" value="unblock">
            <input type="hidden" name="id" value="<?= (int)$x['id'] ?>">
            <button class="btn" type="submit">Снять блокировку</button>
          </form>
        <?php else: ?>
          <span class="badge available">Активен</span>
          <?php if ($x['role'] !== 'admin' && (int)$x['id'] !== (int)$u['id']): ?>
            <form method="post" style="display:inline"
                  onsubmit="return confirm('Заблокировать пользователя «<?= e($x['login']) ?>»?');">
              <input type="hidden" name="action" value="block">
              <input type="hidden" name="id" value="<?= (int)$x['id'] ?>">
              <button class="btn" type="submit" style="color:#a02020">Заблокировать</button>
            </form>
          <?php endif; ?>
        <?php endif; ?>
      </td>
            <td class="row-actions">
        <a href="users.php?edit=<?= $x['id'] ?>" title="Редактировать">✎</a>

        <?php if ((int)$x['id'] !== (int)$u['id']): ?>
          <form method="post" style="display:inline"
                onsubmit="return confirm('Удалить пользователя «<?= e($x['login']) ?>»?\nЭто действие необратимо.');">
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="id" value="<?= (int)$x['id'] ?>">
            <button type="submit" class="btn-link" title="Удалить">🗑</button>
          </form>
        <?php endif; ?>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>

<?php
$edit = null;
if (isset($_GET['edit'])) {
    $st = db()->prepare('SELECT id,login,name,email,role,avatar_initials,is_blocked,failed_attempts,blocked_until,created_at
                     FROM users WHERE login LIKE ? OR name LIKE ? OR email LIKE ? ORDER BY id DESC LIMIT 100');
    $st->execute([(int)$_GET['edit']]);
    $edit = $st->fetch() ?: null;
} elseif (isset($_GET['add'])) {
    $edit = ['id'=>0,'login'=>'','name'=>'','email'=>'','role'=>'user'];
}
if ($edit !== null):
?>
<div class="modal">
  <form method="post" class="modal-card">
    <h2><?= $edit['id'] ? 'Редактировать пользователя' : 'Создать пользователя' ?></h2>
    <input type="hidden" name="action" value="<?= $edit['id'] ? 'update' : 'create' ?>">
    <input type="hidden" name="id" value="<?= (int)$edit['id'] ?>">

    <?php if (!$edit['id']): ?>
      <label>Логин<input name="login" value="<?= e($edit['login']) ?>" required></label>
    <?php else: ?>
      <label>Логин (не меняется)<input value="<?= e($edit['login']) ?>" disabled></label>
    <?php endif; ?>

    <label>Имя<input name="name" value="<?= e($edit['name']) ?>" required></label>
    <label>Email<input type="email" name="email" value="<?= e($edit['email']) ?>" required></label>
    <label>Пароль (<?= $edit['id'] ? 'оставьте пустым, чтобы не менять' : 'мин. 6 символов' ?>)
      <input type="password" name="password" <?= $edit['id'] ? '' : 'required' ?>>
    </label>
    <label>Роль<select name="role">
      <option value="user"  <?= $edit['role']==='user' ? 'selected' : '' ?>>Пользователь</option>
      <option value="admin" <?= $edit['role']==='admin' ? 'selected' : '' ?>>Администратор</option>
    </select></label>
    <div class="modal-actions">
      <a class="btn" href="users.php">Отмена</a>
      <button class="btn primary">Сохранить</button>
    </div>
  </form>
</div>
<?php endif; ?>
<?php require __DIR__ . '/includes/footer.php'; ?>