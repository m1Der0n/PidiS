<?php
$title = 'Контакты';
require __DIR__ . '/includes/header.php';

$isAdmin = $u['role'] === 'admin';

// ============================================================
// Отметить прочитанным (только админ)
// ============================================================
if (isset($_GET['read'])) {
    if (!$isAdmin) { http_response_code(403); exit('Доступ запрещён'); }
    db()->prepare('UPDATE messages SET is_read=1 WHERE id=?')->execute([(int)$_GET['read']]);
    header('Location: contacts.php'); exit;
}

// ============================================================
// Отправка сообщения читателем
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_message'])) {
    $body = trim($_POST['body'] ?? '');
    if ($body === '') {
        flash_set('error', 'Введите текст сообщения.');
    } else {
        // Если в таблице есть user_id — добавьте его в INSERT и в список полей
        db()->prepare('INSERT INTO messages (name, email, body) VALUES (?,?,?)')
           ->execute([$u['name'], $u['email'], $body]);
        log_action('Сообщение от читателя', $u['login']);
        flash_set('info', 'Сообщение отправлено. Мы свяжемся с вами.');
    }
    header('Location: contacts.php'); exit;
}

// ============================================================
// Выборка сообщений
// ============================================================
if ($isAdmin) {
    $messages = db()->query('SELECT * FROM messages ORDER BY id DESC LIMIT 20')->fetchAll();
    $unread   = (int) db()->query('SELECT COUNT(*) FROM messages WHERE is_read=0')->fetchColumn();
} else {
    // Читатель видит только свои обращения (по email).
    // Если есть user_id — замените на: WHERE user_id = ? и execute([$u['id']])
    $st = db()->prepare('SELECT * FROM messages WHERE email = ? ORDER BY id DESC LIMIT 20');
    $st->execute([$u['email']]);
    $messages = $st->fetchAll();
    $unread   = 0;
}

require __DIR__ . '/includes/sidebar.php';
$flash = flash_get();
?>
<h1>Всегда на связи</h1>
<p class="muted">
  Контактная информация библиотеки и обращения читателей.
  <?php if ($isAdmin): ?>
    <b><?= $unread ?></b> новых сообщений
  <?php endif; ?>
</p>

<?php if ($flash): ?>
  <p class="<?= $flash['type']==='info'?'ok':'error' ?>">
    <?= $flash['type']==='info' ? '✅' : '⚠️' ?> <?= e($flash['text']) ?>
  </p>
<?php endif; ?>

<section class="grid2">
  <div class="panel">
    <h2>Как нас найти</h2>
    <p><b>Адрес:</b> Москва, ул. Большая Никитская, 12</p>
    <p><b>Телефон:</b> +7 (495) 123-45-67</p>
    <p><b>Email:</b> info@library.ru</p>
    <p><b>Часы работы:</b> Пн–Пт 09:00–20:00 · Сб 10:00–18:00 · Вс выходной</p>
  </div>

  <?php if ($isAdmin): ?>
    <div class="panel">
      <h2>Входящие сообщения</h2>
      <?php if (!$messages): ?>
        <p class="muted">😕 Сообщений пока нет.</p>
      <?php else: ?>
        <ul class="messages">
          <?php foreach ($messages as $m): ?>
            <li class="<?= $m['is_read'] ? 'read' : '' ?>">
              <b><?= e($m['name']) ?></b>
              <small><?= date('d.m.Y', strtotime($m['created_at'])) ?></small>
              <p><?= e($m['body']) ?></p>
              <?php if (!$m['is_read']): ?>
                <a href="contacts.php?read=<?= (int)$m['id'] ?>">Отметить прочитанным</a>
              <?php endif; ?>
            </li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>
    </div>
  <?php else: ?>
    <div class="panel">
      <h2>Написать нам</h2>
      <form method="post">
        <label>Сообщение
          <textarea name="body" rows="5" required placeholder="Ваш вопрос или пожелание..."></textarea>
        </label>
        <button class="btn primary" name="send_message">Отправить</button>
      </form>
    </div>
  <?php endif; ?>
</section>

<?php if (!$isAdmin): ?>
<section class="panel">
  <h2>Мои обращения</h2>
  <?php if (!$messages): ?>
    <p class="muted">Вы ещё не отправляли сообщений.</p>
  <?php else: ?>
    <ul class="messages">
      <?php foreach ($messages as $m): ?>
        <li class="<?= $m['is_read'] ? 'read' : '' ?>">
          <small><?= date('d.m.Y H:i', strtotime($m['created_at'])) ?></small>
          <p><?= e($m['body']) ?></p>
          <small class="muted">
            <?= $m['is_read'] ? '✓ Прочитано сотрудником' : '⏳ Ожидает ответа' ?>
          </small>
        </li>
      <?php endforeach; ?>
    </ul>
  <?php endif; ?>
</section>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>