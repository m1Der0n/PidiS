<?php
require_once __DIR__ . '/auth.php';

header('Content-Type: application/json; charset=utf-8');

function jok(array $data = []): never {
    echo json_encode(['ok' => true] + $data, JSON_UNESCAPED_UNICODE);
    exit;
}
function jerr(string $msg, int $code = 400): never {
    http_response_code($code);
    echo json_encode(['ok' => false, 'error' => $msg], JSON_UNESCAPED_UNICODE);
    exit;
}

$action = $_GET['action'] ?? $_POST['action'] ?? '';
$input  = $_POST;

if (($_SERVER['CONTENT_TYPE'] ?? '') === 'application/json') {
    $json = json_decode(file_get_contents('php://input'), true);
    if (is_array($json)) $input = array_merge($input, $json);
}

try {
    switch ($action) {

        /* ============================================================
         * CAPTCHA.NEW
         * Сервер:
         *   1) собирает правильный порядок part1..part4 (parts[0..3])
         *   2) перемешивает порядок показа — НО не даёт «уже собранный»
         *   3) отдаёт клиенту:
         *      - images: URL в порядке показа (перемешанные)
         *      - order:  для каждого слота — какой индекс части в нём стоит
         *                (это то, что клиент должен вернуть после сборки)
         * ============================================================ */
        case 'captcha.new': {
            $dir = __DIR__ . '/assets/captcha/puzzle';
            $parts = [];
            for ($i = 1; $i <= 4; $i++) {
                $found = null;
                foreach (['part', ''] as $prefix) {
                    foreach (['jpg', 'jpeg', 'png', 'webp'] as $ext) {
                        $p = "$dir/{$prefix}{$i}.{$ext}";
                        if (is_file($p)) { $found = basename($p); break 2; }
                    }
                }
                if (!$found) jerr("Не найден файл части $i в assets/captcha/puzzle/", 500);
                $parts[] = $found;   // parts[0]=part1, parts[1]=part2, ...
            }

            // Перемешиваем, но не даём выпасть уже собранному порядку
            do {
                $order = [0, 1, 2, 3];
                shuffle($order);
            } while ($order === [0, 1, 2, 3]);

            $_SESSION['captcha'] = [
                'parts' => $parts,      // правильный порядок файлов
                'order' => $order,      // текущий порядок показа
                'time'  => time(),
            ];

            // images[slot] = URL части, которая стоит в слоте
            $images = array_map(
                fn($partIdx) => 'assets/captcha/puzzle/' . $parts[$partIdx],
                $order
            );

            jok([
                'images' => $images,   // для отображения
                'order'  => $order,    // для инициализации state.current
            ]);
        }

        /* ============================================================
         * CAPTCHA.CHECK
         * Клиент присылает answer = "a,b,c,d", где
         *   answer[slot] = индекс части (0..3), стоящей в слоте.
         * Правильно = [0,1,2,3]: в слоте 0 part1, в слоте 1 part2 и т.д.
         * ============================================================ */
        case 'captcha.check': {
            // Уже проходили — не пересобираем
            if (!empty($_SESSION['captcha_passed'])) {
                jok(['passed' => true, 'already' => true]);
            }

                        // Не засчитываем ошибку капчи, если нет логина
            $loginFromForm = trim((string)($input['login'] ?? ''));
            $passwordFromForm = (string)($input['password'] ?? '');

            if ($loginFromForm === '') {
                jerr('Введите логин, чтобы засчитать попытку.', 400);
            }

            $c = $_SESSION['captcha'] ?? null;
            if (!$c) jerr('Задание не найдено. Обновите страницу.', 400);

            if (time() - $c['time'] > 600) {
                unset($_SESSION['captcha']);
                jerr('Время истекло. Обновите задание.', 410);
            }

            $answer = trim((string)($input['answer'] ?? ''));
            if ($answer === '') {
                jerr('Некорректные данные капчи.', 400);
            }

            $parts = explode(',', $answer);
            if (count($parts) !== 4) {
                jerr('Некорректные данные капчи.', 400);
            }

            $userOrder = [];
            foreach ($parts as $p) {
                if (!ctype_digit(trim($p))) {
                    jerr('Некорректные данные капчи.', 400);
                }
                $userOrder[] = (int)trim($p);
            }

            // Каждая часть должна встречаться ровно один раз
            $sorted = $userOrder;
            sort($sorted);
            if ($sorted !== [0, 1, 2, 3]) {
                jerr('Некорректные данные капчи.', 400);
            }

            // Правильная сборка = порядок [0,1,2,3]
            $ok = ($userOrder === [0, 1, 2, 3]);

                        if (!$ok) {
                // Засчитываем попытку только если логин и пароль заполнены
                if ($loginFromForm !== '' && $passwordFromForm !== '') {
                    auth_register_captcha_failure($loginFromForm);
                }
                unset($_SESSION['captcha']);
                jerr('Неверно. Соберите картинку заново.', 422);
            }

            $_SESSION['captcha_passed'] = true;
            unset($_SESSION['captcha']);
            jok(['passed' => true]);
        }

        case 'captcha_pass': {
            $_SESSION['captcha_passed'] = true;
            jok(['captcha' => true]);
        }

        case 'stats': {
            auth_require_api();
            jok([
                'books'   => (int) db()->query('SELECT COUNT(*) FROM books')->fetchColumn(),
                'users'   => (int) db()->query('SELECT COUNT(*) FROM users')->fetchColumn(),
                'issued'  => (int) db()->query("SELECT COUNT(*) FROM books WHERE status='issued'")->fetchColumn(),
                'overdue' => (int) db()->query("SELECT COUNT(*) FROM loans WHERE returned_at IS NULL AND due_at < CURDATE()")->fetchColumn(),
            ]);
        }

        case 'books.list': {
            auth_require_api();
            $q     = trim($input['q'] ?? '');
            $genre = $input['genre'] ?? '';
            $page  = max(1, (int)($input['page'] ?? 1));
            $per   = min(50, max(1, (int)($input['per'] ?? 8)));

            $where = []; $params = [];
            if ($q !== '') {
                $where[] = '(title LIKE ? OR author LIKE ? OR isbn LIKE ?)';
                array_push($params, "%$q%", "%$q%", "%$q%");
            }
            if ($genre !== '') { $where[] = 'genre = ?'; $params[] = $genre; }
            $w = $where ? 'WHERE ' . implode(' AND ', $where) : '';

            $cnt = db()->prepare("SELECT COUNT(*) FROM books $w");
            $cnt->execute($params);
            $total = (int)$cnt->fetchColumn();

            $off = ($page - 1) * $per;
            $st = db()->prepare("SELECT id,title,author,genre,isbn,year,quantity,status
                                 FROM books $w ORDER BY id DESC LIMIT $per OFFSET $off");
            $st->execute($params);

            jok(['items' => $st->fetchAll(), 'total' => $total, 'page' => $page, 'per' => $per]);
        }

        case 'books.create': {
            auth_require_api();
            if (!auth_can('admin')) jerr('Недостаточно прав', 403);

            $data = [
                'title'    => trim($input['title'] ?? ''),
                'author'   => trim($input['author'] ?? ''),
                'genre'    => trim($input['genre'] ?? ''),
                'isbn'     => trim($input['isbn'] ?? ''),
                'year'     => (int)($input['year'] ?? 0),
                'quantity' => (int)($input['quantity'] ?? 0),
                'status'   => in_array($input['status'] ?? '', ['available', 'issued', 'repair'], true)
                              ? $input['status'] : 'available',
            ];
            if ($data['title'] === '' || $data['author'] === '') jerr('Укажите название и автора');

            $st = db()->prepare('INSERT INTO books (title,author,genre,isbn,year,quantity,status)
                                 VALUES (:title,:author,:genre,:isbn,:year,:quantity,:status)');
            $st->execute($data);
            log_action('Добавление книги (API)', $data['title']);
            jok(['id' => (int) db()->lastInsertId()]);
        }

        case 'books.delete': {
            auth_require_api();
            if (!auth_can('admin')) jerr('Только администратор может удалять', 403);
            $id = (int)($input['id'] ?? 0);
            if ($id <= 0) jerr('Некорректный id');

            $st = db()->prepare('SELECT title FROM books WHERE id = ?');
            $st->execute([$id]);
            $title = $st->fetchColumn();
            if ($title === false) jerr('Книга не найдена', 404);

            db()->prepare('DELETE FROM books WHERE id = ?')->execute([$id]);
            log_action('Удаление книги (API)', $title);
            jok(['deleted' => $id]);
        }

                case 'messages.read': {
            $u = auth_require_api();
            if ($u['role'] !== 'admin') {
                jerr('Только сотрудник может отмечать сообщения прочитанными', 403);
            }
            $id = (int)($input['id'] ?? 0);
            if ($id <= 0) jerr('Некорректный id');
            db()->prepare('UPDATE messages SET is_read = 1 WHERE id = ?')->execute([$id]);
            jok(['read' => $id]);
        }

        case 'messages.list': {
            $u = auth_require_api();

            if ($u['role'] === 'admin') {
                // Сотрудник видит все сообщения
                $rows = db()->query('SELECT id,name,email,body,is_read,created_at
                                     FROM messages ORDER BY id DESC LIMIT 50')->fetchAll();
            } else {
                // Читатель видит только свои обращения (по email).
                // Если в messages есть user_id — замените на WHERE user_id = ? и execute([$u['id']])
                $st = db()->prepare('SELECT id,body,is_read,created_at
                                     FROM messages WHERE email = ? ORDER BY id DESC LIMIT 50');
                $st->execute([$u['email']]);
                $rows = $st->fetchAll();
            }
            jok(['items' => $rows]);
        }

        case 'users.create': {
            auth_require_api();
            if (!auth_can('admin')) jerr('Только администратор', 403);

            $login = trim($input['login'] ?? '');
            $name  = trim($input['name'] ?? '');
            $email = trim($input['email'] ?? '');
            $pass  = $input['password'] ?? '';
            $role  = in_array($input['role'] ?? '', ['admin', 'user'], true)
                     ? $input['role'] : 'user';

            if ($login === '') jerr('Укажите логин');
            if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) jerr('Проверьте имя и email');
            $passErr = password_policy_error($pass);
if ($passErr !== null) jerr($passErr);

            $st = db()->prepare('SELECT 1 FROM users WHERE login = ?');
            $st->execute([$login]);
            if ($st->fetchColumn()) {
                jerr("Пользователь с логином «{$login}» уже существует", 409);
            }

            $initials = mb_strtoupper(
                mb_substr($name, 0, 1) . mb_substr(explode(' ', $name)[1] ?? '', 0, 1)
            );

            try {
                $st = db()->prepare('INSERT INTO users (login,name,email,password_hash,role,avatar_initials)
                                     VALUES (?,?,?,?,?,?)');
                $st->execute([$login, $name, $email, password_hash($pass, PASSWORD_DEFAULT), $role, $initials]);
            } catch (PDOException $e) {
                if ($e->getCode() === '23000') jerr('Пользователь с таким email уже существует', 409);
                throw $e;
            }
            log_action('Создание пользователя (API)', $login);
            jok(['id' => (int) db()->lastInsertId()]);
        }

        case 'activity.list': {
            auth_require_api();
            if (!auth_can('admin')) jerr('Недостаточно прав', 403);
            $rows = db()->query(
                'SELECT a.id, a.action, a.entity, a.created_at, u.name AS user_name
                 FROM activity_log a LEFT JOIN users u ON u.id = a.user_id
                 ORDER BY a.id DESC LIMIT 100'
            )->fetchAll();
            jok(['items' => $rows]);
        }

        default:
            jerr('Неизвестное действие: ' . $action, 404);
    }
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'Внутренняя ошибка сервера'], JSON_UNESCAPED_UNICODE);
}