<?php
$title = 'Каталог';
require __DIR__ . '/includes/header.php';

$isAdmin = $u['role'] === 'admin';

// ============================================================
// СОХРАНЕНИЕ / ОБНОВЛЕНИЕ КНИГИ (только админ)
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_book'])) {
    if (!$isAdmin) { http_response_code(403); exit('Доступ запрещён'); }

    $id = (int)($_POST['id'] ?? 0);
    $data = [
        'title'    => trim($_POST['title'] ?? ''),
        'author'   => trim($_POST['author'] ?? ''),
        'genre'    => trim($_POST['genre'] ?? ''),
        'isbn'     => trim($_POST['isbn'] ?? ''),
        'year'     => (int)($_POST['year'] ?? 0),
        'quantity' => (int)($_POST['quantity'] ?? 0),
        'status'   => in_array($_POST['status'] ?? '', ['available', 'issued', 'repair'], true)
                      ? $_POST['status'] : 'available',
    ];
    if ($id) {
        $st = db()->prepare('UPDATE books SET title=?,author=?,genre=?,isbn=?,year=?,quantity=?,status=? WHERE id=?');
        $st->execute([...array_values($data), $id]);
        log_action('Обновление книги', $data['title']);
    } else {
        $st = db()->prepare('INSERT INTO books (title,author,genre,isbn,year,quantity,status) VALUES (?,?,?,?,?,?,?)');
        $st->execute(array_values($data));
        log_action('Добавление книги', $data['title']);
    }
    header('Location: catalog.php'); exit;
}

// ============================================================
// УДАЛЕНИЕ (только админ)
// ============================================================
if (isset($_GET['delete'])) {
    if (!$isAdmin) { http_response_code(403); exit('Доступ запрещён'); }
    db()->prepare('DELETE FROM books WHERE id=?')->execute([(int)$_GET['delete']]);
    log_action('Удаление книги');
    header('Location: catalog.php'); exit;
}

// ============================================================
// ЭКСПОРТ CSV (только админ)
// ============================================================
if (isset($_GET['export'])) {
    if (!$isAdmin) { http_response_code(403); exit('Доступ запрещён'); }
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=books.csv');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['ID','Название','Автор','Жанр','ISBN','Год','Кол-во','Статус']);
    foreach (db()->query('SELECT * FROM books ORDER BY id') as $r) fputcsv($out, $r);
    exit;
}

// ============================================================
// ФИЛЬТРЫ
// ============================================================
$q        = trim($_GET['q'] ?? '');
$author   = trim($_GET['author'] ?? '');
$genre    = $_GET['genre'] ?? '';
$status   = $_GET['status'] ?? '';
$dateFrom = $_GET['date_from'] ?? '';
$dateTo   = $_GET['date_to'] ?? '';
$page     = max(1, (int)($_GET['page'] ?? 1));
$per      = 10;

$where  = [];
$params = [];
$needJoin = false;

if ($q !== '')      { $where[] = 'b.title LIKE ?';  $params[] = "%$q%"; }
if ($author !== '') { $where[] = 'b.author LIKE ?'; $params[] = "%$author%"; }
if ($genre !== '')  { $where[] = 'b.genre = ?';     $params[] = $genre; }
if ($status !== '') { $where[] = 'b.status = ?';    $params[] = $status; }
if ($dateFrom !== '') { $where[] = 'DATE(l.taken_at) >= ?'; $params[] = $dateFrom; $needJoin = true; }
if ($dateTo !== '')   { $where[] = 'DATE(l.taken_at) <= ?'; $params[] = $dateTo;   $needJoin = true; }

$w = $where ? 'WHERE ' . implode(' AND ', $where) : '';
$join = $needJoin ? 'INNER JOIN loans l ON l.book_id = b.id' : '';

// ============================================================
// ПОДСЧЁТ И ВЫБОРКА
// ============================================================
$cnt = db()->prepare("SELECT COUNT(DISTINCT b.id) FROM books b $join $w");
$cnt->execute($params);
$total = (int)$cnt->fetchColumn();

$pages  = max(1, ceil($total / $per));
$offset = ($page - 1) * $per;

$st = db()->prepare("
    SELECT DISTINCT b.*
    FROM books b
    $join
    $w
    ORDER BY b.id DESC
    LIMIT $per OFFSET $offset
");
$st->execute($params);
$books = $st->fetchAll();

$genres = db()->query("SELECT DISTINCT genre FROM books WHERE genre IS NOT NULL ORDER BY genre")->fetchAll(PDO::FETCH_COLUMN);

require __DIR__ . '/includes/sidebar.php';
$statuses = ['available'=>'В наличии', 'issued'=>'Выдана', 'repair'=>'На ремонте'];
?>
<h1>Книжный фонд</h1>
<p class="muted"><?= number_format($total,0,'',' ') ?> книг по вашему запросу</p>

<!-- ============================================================
     ФОРМА ФИЛЬТРОВ
     ============================================================ -->
<form class="catalog-filters" method="get">
  <label>
    <small class="muted">Название</small>
    <input name="q" placeholder="например, «Мастер»" value="<?= e($q) ?>">
  </label>

  <label>
    <small class="muted">Автор</small>
    <input name="author" placeholder="например, «Булгаков»" value="<?= e($author) ?>">
  </label>

  <label>
    <small class="muted">Жанр</small>
    <select name="genre">
      <option value="">Все жанры</option>
      <?php foreach ($genres as $g): ?>
        <option <?= $genre===$g ? 'selected' : '' ?>><?= e($g) ?></option>
      <?php endforeach; ?>
    </select>
  </label>

  <label>
    <small class="muted">Статус</small>
    <select name="status">
      <option value="">Все статусы</option>
      <?php foreach ($statuses as $k => $v): ?>
        <option value="<?= $k ?>" <?= $status===$k ? 'selected' : '' ?>><?= $v ?></option>
      <?php endforeach; ?>
    </select>
  </label>

  <label>
    <small class="muted">Выдана с</small>
    <input type="date" name="date_from" value="<?= e($dateFrom) ?>">
  </label>

  <label>
    <small class="muted">по</small>
    <input type="date" name="date_to" value="<?= e($dateTo) ?>">
  </label>

  <button class="btn primary" type="submit">🔍 Найти</button>
  <a class="btn" href="catalog.php">Сбросить</a>

  <a class="btn" href="catalog_pdf.php?<?= http_build_query($_GET) ?>" target="_blank">📄 Экспорт PDF</a>

  <?php if ($isAdmin): ?>
    <a class="btn" href="catalog.php?export=1">Экспорт CSV</a>
    <a class="btn primary" href="catalog.php?add=1">+ Добавить книгу</a>
  <?php endif; ?>
</form>

<!-- ============================================================
     РЕЗУЛЬТАТЫ
     ============================================================ -->
<?php if (!$books): ?>
  <div class="no-results">
    <p>😕 По вашему запросу ничего не найдено.</p>
    <p>Попробуйте изменить условия поиска или <a href="catalog.php">сбросить фильтры</a>.</p>
  </div>
<?php else: ?>
  <table class="table">
    <thead>
      <tr>
        <th>Название</th>
        <th>Автор</th>
        <th>ISBN</th>
        <th>Кол-во</th>
        <th>Статус</th>
        <th>Последняя выдача</th>
        <?php if ($isAdmin): ?><th></th><?php endif; ?>
      </tr>
    </thead>
    <tbody>
    <?php foreach ($books as $b): ?>
      <?php
        $ls = db()->prepare("SELECT taken_at FROM loans WHERE book_id = ? ORDER BY taken_at DESC LIMIT 1");
        $ls->execute([$b['id']]);
        $lastLoan = $ls->fetchColumn();
      ?>
      <tr>
        <td>
          <b><?= e($b['title']) ?></b><br>
          <small class="muted"><?= e($b['genre']) ?> • <?= (int)$b['year'] ?></small>
        </td>
        <td><?= e($b['author']) ?></td>
        <td><?= e($b['isbn']) ?></td>
        <td><?= (int)$b['quantity'] ?></td>
        <td><span class="badge <?= $b['status'] ?>"><?= $statuses[$b['status']] ?? $b['status'] ?></span></td>
        <td><?= $lastLoan ? date('d.m.Y', strtotime($lastLoan)) : '—' ?></td>
        <?php if ($isAdmin): ?>
          <td class="row-actions">
            <a href="catalog.php?edit=<?= $b['id'] ?>">✎</a>
            <a href="catalog.php?delete=<?= $b['id'] ?>" onclick="return confirm('Удалить книгу?')">🗑</a>
          </td>
        <?php endif; ?>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>

  <!-- Пагинация -->
  <nav class="pager">
    <?php for ($i = 1; $i <= min($pages, 7); $i++): ?>
      <a class="<?= $i===$page ? 'active' : '' ?>"
         href="?<?= http_build_query(array_merge($_GET, ['page' => $i])) ?>"><?= $i ?></a>
    <?php endfor; ?>
    <?php if ($pages > 7): ?>
      … <a href="?<?= http_build_query(array_merge($_GET, ['page' => $pages])) ?>"><?= $pages ?></a>
    <?php endif; ?>
  </nav>
<?php endif; ?>

<!-- ============================================================
     МОДАЛКА добавления / редактирования (только админ)
     ============================================================ -->
<?php
$edit = null;
if ($isAdmin) {
    if (isset($_GET['edit'])) {
        $st = db()->prepare('SELECT * FROM books WHERE id=?'); $st->execute([(int)$_GET['edit']]); $edit = $st->fetch();
    } elseif (isset($_GET['add'])) {
        $edit = ['id'=>0, 'title'=>'', 'author'=>'', 'genre'=>'', 'isbn'=>'', 'year'=>date('Y'), 'quantity'=>1, 'status'=>'available'];
    }
}
if ($edit !== null):
?>
<div class="modal">
  <form method="post" class="modal-card">
    <h2><?= $edit['id'] ? 'Редактировать книгу' : 'Добавить книгу' ?></h2>
    <input type="hidden" name="id" value="<?= (int)$edit['id'] ?>">
    <label>Название<input name="title" value="<?= e($edit['title']) ?>" required></label>
    <label>Автор<input name="author" value="<?= e($edit['author']) ?>" required></label>
    <label>Жанр<input name="genre" value="<?= e($edit['genre']) ?>"></label>
    <label>ISBN<input name="isbn" value="<?= e($edit['isbn']) ?>"></label>
    <label>Год<input type="number" name="year" value="<?= (int)$edit['year'] ?>"></label>
    <label>Количество<input type="number" name="quantity" value="<?= (int)$edit['quantity'] ?>"></label>
    <label>Статус<select name="status">
      <?php foreach ($statuses as $k => $v): ?>
        <option value="<?= $k ?>" <?= $edit['status']===$k ? 'selected' : '' ?>><?= $v ?></option>
      <?php endforeach; ?>
    </select></label>
    <div class="modal-actions">
      <a class="btn" href="catalog.php">Отмена</a>
      <button class="btn primary" name="save_book">Сохранить</button>
    </div>
  </form>
</div>
<?php endif; ?>
<?php require __DIR__ . '/includes/footer.php'; ?>