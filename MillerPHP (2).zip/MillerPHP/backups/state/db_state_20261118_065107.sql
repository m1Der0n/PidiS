/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.11-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: library_db
-- ------------------------------------------------------
-- Server version	10.11.11-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activity_log`
--

DROP TABLE IF EXISTS `activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(255) NOT NULL,
  `entity` varchar(80) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_log`
--

LOCK TABLES `activity_log` WRITE;
/*!40000 ALTER TABLE `activity_log` DISABLE KEYS */;
INSERT INTO `activity_log` VALUES
(1,1,'Вход в систему','admin','2026-11-10 10:29:07'),
(2,1,'Выход из системы',NULL,'2026-11-10 10:33:01'),
(3,1,'Вход в систему','admin','2026-11-10 10:35:34'),
(4,1,'Выход из системы',NULL,'2026-11-10 10:35:36'),
(5,NULL,'Блокировка учётной записи (капча)','admin','2026-11-10 10:35:48'),
(6,1,'Вход в систему','admin','2026-11-10 10:37:39'),
(7,1,'Выход из системы',NULL,'2026-11-10 10:38:11'),
(8,1,'Вход в систему','admin','2026-11-10 10:46:04'),
(9,1,'Выход из системы',NULL,'2026-11-10 10:46:14'),
(10,1,'Вход в систему','admin','2026-11-10 10:46:42'),
(11,1,'Удаление книги',NULL,'2026-11-10 10:46:59'),
(12,1,'Обновление книги','Маленький принц','2026-11-10 10:47:05'),
(13,1,'Выход из системы',NULL,'2026-11-10 10:47:29'),
(14,1,'Вход в систему','admin','2026-11-10 10:59:00'),
(15,1,'Триггер: Создание пользователя','user_id=4, Создание: без изменений','2026-11-10 11:00:15'),
(16,1,'Блокировка пользователя','user40','2026-11-10 11:08:04'),
(17,1,'Разблокировка пользователя','user40','2026-11-10 11:08:06'),
(18,1,'Блокировка пользователя','user40','2026-11-10 11:08:11'),
(19,1,'Разблокировка пользователя','user40','2026-11-10 11:08:13'),
(20,1,'Триггер: Создание пользователя','user_id=5, Создание: без изменений','2026-11-10 11:09:55'),
(21,1,'Выход из системы',NULL,'2026-11-10 11:10:14'),
(22,1,'Вход в систему','admin','2026-11-10 11:10:32'),
(23,1,'Выход из системы',NULL,'2026-11-10 11:10:35'),
(24,1,'Вход в систему','admin','2026-11-10 11:11:07'),
(25,1,'Выход из системы',NULL,'2026-11-10 11:11:11'),
(26,1,'Вход в систему','admin','2026-11-10 11:11:36'),
(27,1,'Бэкап состояния','db_state_20261110_042156.sql','2026-11-10 11:21:56'),
(28,1,'Бэкап состояния','db_state_20261110_043050.sql','2026-11-10 11:30:50'),
(29,1,'Восстановление состояния','db_state_20261110_043059.sql','2026-11-10 11:31:43'),
(30,1,'Бэкап состояния','db_state_20261110_043723.sql','2026-11-10 11:37:23'),
(31,1,'Выход из системы',NULL,'2026-11-10 11:37:27'),
(32,1,'Вход в систему','admin','2026-11-18 12:56:20'),
(33,1,'Выход из системы',NULL,'2026-11-18 12:56:35'),
(34,2,'Вход в систему','user25','2026-11-18 12:56:44'),
(35,2,'Выход из системы',NULL,'2026-11-18 13:12:36'),
(36,1,'Вход в систему','admin','2026-11-18 13:50:59');
/*!40000 ALTER TABLE `activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `books`
--

DROP TABLE IF EXISTS `books`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `books` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `genre` varchar(80) DEFAULT NULL,
  `isbn` varchar(32) DEFAULT NULL,
  `year` smallint(6) DEFAULT NULL,
  `quantity` int(11) DEFAULT 0,
  `status` enum('available','issued','repair') DEFAULT 'available',
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `books`
--

LOCK TABLES `books` WRITE;
/*!40000 ALTER TABLE `books` DISABLE KEYS */;
INSERT INTO `books` VALUES
(1,'Мастер и Маргарита','Михаил Булгаков','Роман','978-5-17-090369-5',2023,24,'available','2026-11-03 11:26:54'),
(2,'Маленький принц','Антуан де Сент-Экзюпери','Детская литература','978-5-699-89136-1',2020,18,'available','2026-11-03 11:26:54');
/*!40000 ALTER TABLE `books` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loans`
--

DROP TABLE IF EXISTS `loans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `loans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `book_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `taken_at` date NOT NULL,
  `due_at` date NOT NULL,
  `returned_at` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `book_id` (`book_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `loans_ibfk_1` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) ON DELETE CASCADE,
  CONSTRAINT `loans_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loans`
--

LOCK TABLES `loans` WRITE;
/*!40000 ALTER TABLE `loans` DISABLE KEYS */;
/*!40000 ALTER TABLE `loans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `email` varchar(160) DEFAULT NULL,
  `body` text NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
INSERT INTO `messages` VALUES
(1,'Мария Кузнецова','m.kuznetsova@mail.ru','Можно продлить книгу «1984»?',0,'2026-11-03 11:26:54');
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notes`
--

DROP TABLE IF EXISTS `notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `id_user` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_notes_user` (`id_user`),
  CONSTRAINT `notes_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notes`
--

LOCK TABLES `notes` WRITE;
/*!40000 ALTER TABLE `notes` DISABLE KEYS */;
INSERT INTO `notes` VALUES
(1,'Конференция ИТ','Список секций и регламент мероприятия.',2,'2027-03-15 10:00:00'),
(2,'План на неделю','Подготовить отчёт по выдаче книг.',1,'2027-03-16 09:30:00'),
(3,'Новые поступления','Оформить витрину с новинками.',3,'2027-03-17 14:15:00'),
(4,'Инвентаризация','Сверить фонд с каталогом за март.',2,'2027-03-18 11:45:00');
/*!40000 ALTER TABLE `notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `k` varchar(64) NOT NULL,
  `v` text DEFAULT NULL,
  PRIMARY KEY (`k`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(60) NOT NULL,
  `name` varchar(120) NOT NULL,
  `email` varchar(160) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('admin','user') NOT NULL DEFAULT 'user',
  `avatar_initials` varchar(4) DEFAULT NULL,
  `failed_attempts` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `is_blocked` tinyint(1) NOT NULL DEFAULT 0,
  `blocked_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `login` (`login`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'admin','Анна Смирнова','admin@library.ru','$2y$10$7FicET1OcwXZBkJAPG28LO/yyfBY033P/HJXBRf6jaPtxUGi1Yzu.','admin','АС',0,0,NULL,'2026-11-03 11:26:54'),
(2,'user25','Мария Кузнецова','m.kuznetsova@mail.ru','$2y$10$7FicET1OcwXZBkJAPG28LO/yyfBY033P/HJXBRf6jaPtxUGi1Yzu.','user','МК',0,0,NULL,'2026-11-03 11:26:54'),
(3,'user40','Алексей Морозов','a.morozov@mail.ru','$2y$10$7FicET1OcwXZBkJAPG28LO/yyfBY033P/HJXBRf6jaPtxUGi1Yzu.','user','АМ',0,0,NULL,'2026-11-03 11:26:54');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'library_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-18 13:51:07
