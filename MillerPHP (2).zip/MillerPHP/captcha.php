<?php
require __DIR__ . '/config.php';
if (($_POST['passed'] ?? '') === '1') {
    $_SESSION['captcha_passed'] = true;
    echo json_encode(['ok' => true]);
}