<?php
$title      = 'О нас';
$publicPage = true;          // доступно гостю
require __DIR__ . '/includes/header.php';

$isAdmin = $u && $u['role'] === 'admin';

// Редактирование — только администратор
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$isAdmin) {
        http_response_code(403);
        flash_set('error', 'Недостаточно прав для редактирования.');
        header('Location: about.php'); exit;
    }
    setting_set('about_title', $_POST['about_title'] ?? '');
    setting_set('about_text',  $_POST['about_text'] ?? '');
    log_action('Обновление страницы «О нас»');
    header('Location: about.php'); exit;
}

$defaultTitle = 'Место, где книги объединяют людей';
$defaultText  = 'С 1954 года мы помогаем читателям открывать новое...';
require __DIR__ . '/includes/sidebar.php';
$flash = flash_get();
?>
<h1>О библиотеке</h1>
<p class="muted">Информация, которую видят читатели на сайте библиотеки.</p>

<?php if ($flash): ?>
  <p class="<?= $flash['type']==='info'?'ok':'error' ?>">
    <?= $flash['type']==='info' ? '✅' : '⚠️' ?> <?= e($flash['text']) ?>
  </p>
<?php endif; ?>

<section class="hero">
  <h2><?= e(setting_get('about_title',$defaultTitle)) ?></h2>
  <p><?= nl2br(e(setting_get('about_text',$defaultText))) ?></p>
</section>

<?php if ($isAdmin): ?>
<form method="post" class="panel">
  <h2>Редактировать страницу</h2>
  <label>Заголовок<input name="about_title" value="<?= e(setting_get('about_title',$defaultTitle)) ?>"></label>
  <label>Текст<textarea name="about_text" rows="6"><?= e(setting_get('about_text',$defaultText)) ?></textarea></label>
  <button class="btn primary">Сохранить</button>
</form>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>