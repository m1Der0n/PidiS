<?php
require_once __DIR__ . '/config.php';

/**
 * Попытка входа.
 * @return array{0:bool, 1:?string, 2:?array} [success, message, user]
 */
function auth_attempt(string $login, string $password, bool $captchaPassed): array
{
    $st = db()->prepare('SELECT * FROM users WHERE login = ? LIMIT 1');
    $st->execute([$login]);
    $u = $st->fetch();

    if (!$u) {
        return [false, MSG_BAD_LOGIN, null];
    }

    // Авторазблокировка, если blocked_until истёк
    if ((int)$u['is_blocked'] === 1
        && !empty($u['blocked_until'])
        && strtotime($u['blocked_until']) <= time()) {
        db()->prepare('UPDATE users SET is_blocked=0, failed_attempts=0, blocked_at=NULL, blocked_until=NULL WHERE id=?')
           ->execute([$u['id']]);
        $u['is_blocked'] = 0;
        $u['failed_attempts'] = 0;
        $u['blocked_until'] = null;
        $u['blocked_at'] = null;
        log_action('Авторазблокировка по истечении срока', $u['login']);
    }

    // Триггер 2: проверка автоблокировки
    if (trigger_check_autoblock($u)) {
        return [false, MSG_BLOCKED, null];
    }

    if (!$captchaPassed) {
        return auth_register_failure($u, MSG_CAPTCHA);
    }

    if (!password_verify($password, $u['password_hash'])) {
        return auth_register_failure($u, MSG_BAD_LOGIN);
    }

    // Успешный вход — сбрасываем счётчик
    db()->prepare('UPDATE users SET failed_attempts = 0 WHERE id = ?')->execute([$u['id']]);
    session_regenerate_id(true);

    $_SESSION['user'] = [
        'id'       => (int)$u['id'],
        'login'    => $u['login'],
        'name'     => $u['name'],
        'email'    => $u['email'],
        'role'     => $u['role'],
        'initials' => $u['avatar_initials'],
    ];
    unset($_SESSION['captcha_passed']);
    log_action('Вход в систему', $u['login']);

    return [true, MSG_SUCCESS, $_SESSION['user']];
}

/** Инкремент счётчика; на 3-й ошибке — блокировка учётки. */
function auth_register_failure(array $u, string $message): array
{
    // Админов не блокируем
    if ($u['role'] === 'admin') {
        db()->prepare('UPDATE users SET failed_attempts = 0 WHERE id = ?')->execute([$u['id']]);
        return [false, $message, null];
    }

    $attempts = (int)$u['failed_attempts'] + 1;

        if ($attempts >= 3) {
        db()->prepare('UPDATE users SET failed_attempts = ?, is_blocked = 1, blocked_at = NOW(), blocked_until = DATE_ADD(NOW(), INTERVAL 1 HOUR) WHERE id = ?')
           ->execute([$attempts, $u['id']]);
        log_action('Блокировка учётной записи (1 час)', $u['login']);
        return [false, MSG_BLOCKED, null];
    }

    db()->prepare('UPDATE users SET failed_attempts = ? WHERE id = ?')
       ->execute([$attempts, $u['id']]);

    return [false, $message, null];
}

/** Засчитать неудачную попытку капчи для конкретного логина. */
function auth_register_captcha_failure(string $login): void
{
    if ($login === '') return;
    $st = db()->prepare('SELECT id, role, failed_attempts, is_blocked FROM users WHERE login = ? LIMIT 1');
    $st->execute([$login]);
    $u = $st->fetch();
    if (!$u || (int)$u['is_blocked'] === 1) return;

    // Админов не блокируем
    if ($u['role'] === 'admin') return;

    $n = (int)$u['failed_attempts'] + 1;
            if ($n >= 3) {
        db()->prepare('UPDATE users SET failed_attempts = ?, is_blocked = 1, blocked_at = NOW(), blocked_until = DATE_ADD(NOW(), INTERVAL 1 HOUR) WHERE id = ?')
           ->execute([$n, $u['id']]);
        log_action('Блокировка учётной записи (капча, 1 час)', $login);
    } else {
        db()->prepare('UPDATE users SET failed_attempts = ? WHERE id = ?')->execute([$n, $u['id']]);
    }
}

function auth_logout(): void
{
    if (!empty($_SESSION['user'])) {
        log_action('Выход из системы');
    }
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
}

function auth_user(): ?array { return $_SESSION['user'] ?? null; }

function auth_require(): array
{
    $u = auth_user();
    if (!$u) { header('Location: login.php'); exit; }
    return $u;
}

function auth_can(string ...$roles): bool
{
    $u = auth_user();
    return $u && in_array($u['role'], $roles, true);
}

function auth_require_api(): array
{
    $u = auth_user();
    if (!$u) {
        http_response_code(401);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['ok' => false, 'error' => 'Требуется авторизация'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    return $u;
}