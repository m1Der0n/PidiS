<?php
$title = 'Бэкапы';
require __DIR__ . '/includes/header.php';

$u = auth_require();
if ($u['role'] !== 'admin') {
    header('Location: index.php');
    exit;
}

$stateDir = __DIR__ . '/backups/state';
if (!is_dir($stateDir)) mkdir($stateDir, 0755, true);

$errors = [];

// ============================================================
// ОБРАБОТКА ДЕЙСТВИЙ
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // --- Создать бэкап ---
    if ($action === 'create') {
        $date = date('Ymd_His');
        $file = $stateDir . "/db_state_$date.sql";

        $cmd = sprintf(
            'mysqldump -u%s -p%s --single-transaction --routines --triggers %s > %s 2>&1',
            escapeshellarg(DB_USER),
            escapeshellarg(DB_PASS),
            escapeshellarg(DB_NAME),
            escapeshellarg($file)
        );
        exec($cmd, $out, $code);

        if ($code !== 0 || !is_file($file) || filesize($file) < 100) {
            $errors[] = 'Ошибка создания бэкапа: ' . implode("\n", $out);
        } else {
            log_action('Бэкап состояния', basename($file));
            flash_set('info', 'Бэкап создан: ' . basename($file));
            header('Location: backups.php'); exit;
        }
    }

    // --- Восстановить ---
    if ($action === 'restore') {
        $file = basename($_POST['file'] ?? '');
        $path = $stateDir . '/' . $file;

        if ($file === '' || str_contains($file, '/') || str_contains($file, '..') || !is_file($path)) {
            $errors[] = 'Файл не найден.';
        } else {
            $cmd = sprintf(
                'mysql -u%s -p%s %s < %s 2>&1',
                escapeshellarg(DB_USER),
                escapeshellarg(DB_PASS),
                escapeshellarg(DB_NAME),
                escapeshellarg($path)
            );
            exec($cmd, $out, $code);

            if ($code === 0) {
                log_action('Восстановление состояния', $file);
                flash_set('info', "Состояние восстановлено из «{$file}».");
            } else {
                $errors[] = 'Ошибка восстановления: ' . implode("\n", $out);
            }
            header('Location: backups.php'); exit;
        }
    }

    // --- Удалить ---
    if ($action === 'delete') {
        $file = basename($_POST['file'] ?? '');
        $path = $stateDir . '/' . $file;

        if ($file === '' || str_contains($file, '/') || str_contains($file, '..') || !is_file($path)) {
            $errors[] = 'Файл не найден.';
        } else {
            unlink($path);
            flash_set('info', "Файл «{$file}» удалён.");
            header('Location: backups.php'); exit;
        }
    }
}

// ============================================================
// СПИСОК БЭКАПОВ
// ============================================================
$files = [];
foreach (glob($stateDir . '/*.sql') as $f) {
    $files[] = [
        'name' => basename($f),
        'size' => filesize($f),
        'date' => filemtime($f),
    ];
}
usort($files, fn($a, $b) => $b['date'] <=> $a['date']);

$totalSize = array_sum(array_column($files, 'size'));

require __DIR__ . '/includes/sidebar.php';
$flash = flash_get();
?>
<h1>Бэкапы состояния системы</h1>
<p class="muted">
  Снимки всех данных: пользователи, книги, заметки, выдачи, сообщения, логи.
  Всего: <b><?= count($files) ?></b> файлов · <b><?= number_format($totalSize / 1024 / 1024, 2, '.', ' ') ?> МБ</b>
</p>

<?php if ($flash): ?>
  <p class="<?= $flash['type']==='info'?'ok':'error' ?>">
    <?= $flash['type']==='info' ? '✅' : '⚠️' ?> <?= e($flash['text']) ?>
  </p>
<?php endif; ?>

<?php if ($errors): ?>
  <div class="error">
    <?php foreach ($errors as $err): ?>
      <p>⚠️ <?= e($err) ?></p>
    <?php endforeach; ?>
  </div>
<?php endif; ?>

<!-- Кнопка создания бэкапа -->
<section class="panel">
  <h2>Создать новый бэкап</h2>
  <p class="muted">Снимок текущего состояния БД: все данные будут сохранены в отдельный файл.</p>
  <form method="post" style="margin-top:10px">
    <input type="hidden" name="action" value="create">
    <button class="btn primary" type="submit">💾 Создать бэкап сейчас</button>
  </form>
</section>

<!-- Список бэкапов -->
<?php if (!$files): ?>
  <div class="panel">
    <p class="muted">😕 Бэкапов пока нет.</p>
    <p>Нажмите «Создать бэкап сейчас», чтобы сделать первый снимок состояния.</p>
  </div>
<?php else: ?>
  <table class="table">
    <thead>
      <tr>
        <th>Дата и время</th>
        <th>Имя файла</th>
        <th>Размер</th>
        <th>Действия</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($files as $f): ?>
        <tr>
          <td><b><?= date('d.m.Y H:i:s', $f['date']) ?></b></td>
          <td><code style="font-size:12px"><?= e($f['name']) ?></code></td>
          <td><?= number_format($f['size'] / 1024, 1, '.', ' ') ?> КБ</td>
          <td style="white-space:nowrap">
            <a class="btn" href="download_state.php?file=<?= urlencode($f['name']) ?>">⬇ Скачать</a>

            <form method="post" style="display:inline"
                  onsubmit="return confirm('Восстановить состояние из <?= e($f['name']) ?>?\n\nВСЕ текущие данные будут перезаписаны данными из этого бэкапа.\n\nПродолжить?');">
              <input type="hidden" name="action" value="restore">
              <input type="hidden" name="file" value="<?= e($f['name']) ?>">
              <button class="btn primary" type="submit">♻ Восстановить</button>
            </form>

            <form method="post" style="display:inline"
                  onsubmit="return confirm('Удалить файл <?= e($f['name']) ?>?');">
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="file" value="<?= e($f['name']) ?>">
              <button class="btn-link" type="submit" title="Удалить">🗑</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>