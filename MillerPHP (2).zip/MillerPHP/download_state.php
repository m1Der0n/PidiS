<?php
require __DIR__ . '/config.php';

$u = current_user();
if (!$u || $u['role'] !== 'admin') {
    die('Доступ запрещён');
}

$file = basename($_GET['file'] ?? '');
$path = __DIR__ . '/backups/state/' . $file;

if ($file === '' || !is_file($path)) {
    http_response_code(404);
    die('Файл не найден');
}

header('Content-Type: application/sql');
header('Content-Disposition: attachment; filename="' . $file . '"');
header('Content-Length: ' . filesize($path));
readfile($path);
exit;