<?php
/**
 * GET /notes — публичный эндпоинт.
 * Формат: [{id, title_user, content, formatted_date}, ...]
 */
require_once __DIR__ . '/config.php';
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(400);
    echo json_encode(['error' => 'Метод не поддерживается. Используйте GET.'], JSON_UNESCAPED_UNICODE);
    exit;
}

$userId = null;
if (isset($_GET['user_id'])) {
    if (!ctype_digit((string)$_GET['user_id'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Параметр user_id должен быть целым числом.'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $userId = (int)$_GET['user_id'];
}

// Для демонстрации теста 500 (в продакшене удалить / закомментировать)
if (!empty($_GET['__simulate_500'])) {
    throw new RuntimeException('Simulated DB failure');
}

try {
    $sql = 'SELECT n.id, n.title, n.content, n.created_at, u.login
            FROM notes n
            INNER JOIN users u ON u.id = n.id_user';
    $params = [];
    if ($userId !== null) { $sql .= ' WHERE n.id_user = ?'; $params[] = $userId; }
    $sql .= ' ORDER BY n.id';

    $st = db()->prepare($sql);
    $st->execute($params);
    $rows = $st->fetchAll();

    $result = array_map(fn($r) => [
        'id'             => (int)$r['id'],
        'title_user'     => $r['title'] . ' - ' . $r['login'],
        'content'        => $r['content'],
        'formatted_date' => date('d.m.Y', strtotime($r['created_at'])),
    ], $rows);

    http_response_code(200);
    echo json_encode($result, JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Ошибка подключения к базе данных'], JSON_UNESCAPED_UNICODE);
}