CREATE DATABASE IF NOT EXISTS library_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE library_db;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  login VARCHAR(60) NOT NULL UNIQUE,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(160) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin','user') NOT NULL DEFAULT 'user',
  avatar_initials VARCHAR(4) DEFAULT NULL,
  failed_attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
  is_blocked TINYINT(1) NOT NULL DEFAULT 0,
  blocked_at DATETIME DEFAULT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE books (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  author VARCHAR(255) NOT NULL,
  genre VARCHAR(80) DEFAULT NULL,
  isbn VARCHAR(32) DEFAULT NULL,
  year SMALLINT DEFAULT NULL,
  quantity INT DEFAULT 0,
  status ENUM('available','issued','repair') DEFAULT 'available',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE loans (
  id INT AUTO_INCREMENT PRIMARY KEY,
  book_id INT NOT NULL,
  user_id INT NOT NULL,
  taken_at DATE NOT NULL,
  due_at DATE NOT NULL,
  returned_at DATE DEFAULT NULL,
  FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE messages (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(160) DEFAULT NULL,
  body TEXT NOT NULL,
  is_read TINYINT(1) DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE activity_log (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT DEFAULT NULL,
  action VARCHAR(255) NOT NULL,
  entity VARCHAR(80) DEFAULT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE settings (
  k VARCHAR(64) PRIMARY KEY,
  v TEXT
);

CREATE TABLE notes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  content TEXT NOT NULL,
  id_user INT NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (id_user) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_notes_user (id_user)
);

-- Пароль всех тестовых юзеров: secret123
-- Сгенерируйте хеш: php -r "echo password_hash('secret123', PASSWORD_DEFAULT);"
-- и подставьте вместо 'PASTE_HASH_HERE'
SET @h = '$2y$10$aNINiuX/oZcpYGrDbGdu/u0D5ABebn4TXYRmG.yPezQkaP1sXoo5u';

INSERT INTO users (login, name, email, password_hash, role, avatar_initials) VALUES
('admin',  'Анна Смирнова',   'admin@library.ru',     @h, 'admin', 'АС'),
('user25', 'Мария Кузнецова', 'm.kuznetsova@mail.ru', @h, 'user',  'МК'),
('user40', 'Алексей Морозов', 'a.morozov@mail.ru',    @h, 'user',  'АМ');

INSERT INTO books (title,author,genre,isbn,year,quantity,status) VALUES
('Мастер и Маргарита','Михаил Булгаков','Роман','978-5-17-090369-5',2023,24,'available'),
('Маленький принц','Антуан де Сент-Экзюпери','Детская литература','978-5-699-89136-1',2022,18,'available'),
('1984','Джордж Оруэлл','Антиутопия','978-5-17-148844-3',2024,12,'issued');

INSERT INTO messages (name,email,body,is_read) VALUES
('Мария Кузнецова','m.kuznetsova@mail.ru','Можно продлить книгу «1984»?',0);

INSERT INTO notes (title, content, id_user, created_at) VALUES
('Конференция ИТ',    'Список секций и регламент мероприятия.', 2, '2027-03-15 10:00:00'),
('План на неделю',    'Подготовить отчёт по выдаче книг.',      1, '2027-03-16 09:30:00'),
('Новые поступления', 'Оформить витрину с новинками.',          3, '2027-03-17 14:15:00'),
('Инвентаризация',    'Сверить фонд с каталогом за март.',      2, '2027-03-18 11:45:00');